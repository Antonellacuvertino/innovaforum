<?php
session_start();
include("conexion.php");

$usuario_id = $_SESSION["usuario_id"];

if (isset($_FILES["foto"])) {
    $nombre = basename($_FILES["foto"]["name"]);
    $destino = "uploads/" . $nombre;

    if (move_uploaded_file($_FILES["foto"]["tmp_name"], $destino)) {
        $conexion->query("UPDATE usuarios SET foto_perfil = '$nombre' WHERE id = $usuario_id");
        echo "✅ Foto actualizada. <a href='perfil.php'>Volver al perfil</a>";
    } else {
        echo "❌ Error al subir imagen.";
    }
} else {
    echo "No se seleccionó ninguna imagen.";
}
?>
