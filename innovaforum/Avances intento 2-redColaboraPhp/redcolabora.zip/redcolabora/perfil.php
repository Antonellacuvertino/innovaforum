<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$id = $_SESSION['usuario_id'];
$sql = "SELECT * FROM usuarios WHERE id = $id";
$result = $conexion->query($sql);
$usuario = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Perfil</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <div class="perfil-container">
        <h2>👤 Perfil de <?= htmlspecialchars($usuario['nombre']) ?></h2>
        <img src="uploads/<?= htmlspecialchars($usuario['foto']) ?>" alt="Foto de perfil" class="foto-perfil">

        <form action="editar_perfil.php" method="POST" enctype="multipart/form-data">
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required>
            <input type="email" name="correo" value="<?= htmlspecialchars($usuario['correo']) ?>" readonly>
            <textarea name="biografia" placeholder="Escribe algo sobre ti..."><?= htmlspecialchars($usuario['biografia']) ?></textarea>
            <label>Cambiar foto de perfil:</label>
            <input type="file" name="foto">
            <button type="submit">Guardar cambios</button>
        </form>

        <h3>📝 Tus publicaciones</h3>
        <ul class="lista-publicaciones">
            <?php
            $sqlPub = "SELECT * FROM publicaciones WHERE usuario_id = $id ORDER BY fecha DESC";
            $pubs = $conexion->query($sqlPub);
            while ($pub = $pubs->fetch_assoc()) {
                echo "<li><strong>" . htmlspecialchars($pub['titulo']) . "</strong><br>" . htmlspecialchars($pub['contenido']) . "</li>";
            }
            ?>
        </ul>

        <a href="publicar.php" class="boton">➕ Nueva publicación</a>
        <a href="cerrar_sesion.php" class="boton">🔒 Cerrar sesión</a>
    </div>
</body>
</html>
