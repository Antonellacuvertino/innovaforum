<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $_POST['titulo'];
    $contenido = $_POST['contenido'];
    $usuario_id = $_SESSION['usuario_id'];

    $sql = "INSERT INTO publicaciones (usuario_id, titulo, contenido) VALUES ($usuario_id, '$titulo', '$contenido')";
    $conexion->query($sql);
    header("Location: perfil.php");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Publicar</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <div class="publicar-container">
        <h2>Crear nueva publicación</h2>
        <form method="POST">
            <input type="text" name="titulo" placeholder="Título" required>
            <textarea name="contenido" placeholder="Escribe tu contenido aquí..." required></textarea>
            <button type="submit">Publicar</button>
        </form>
        <a href="perfil.php" class="boton">Volver al perfil</a>
    </div>
</body>
</html>
