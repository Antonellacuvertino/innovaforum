<?php include("conexion.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>RedColabora</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>

  <div class="sidebar">
    <h2>RedColabora</h2>
    <a href="index.php">Inicio</a>
    <a href="perfil.php">Mi Perfil</a>
    <a href="publicar.php">Publicar</a>
    <a href="logout.php">Cerrar sesión</a>
  </div>

  <div class="main">
    <div class="header">
      <h1>Bienvenida, Antonella</h1>
      <input type="text" placeholder="Buscar en RedColabora..." />
    </div>

    <div class="container">
      <div class="card">
        <h2>Publicaciones recientes</h2>
        <?php
          $sql = "SELECT * FROM publicaciones ORDER BY fecha DESC";
          $resultado = $conexion->query($sql);
          while($fila = $resultado->fetch_assoc()) {
            echo "<div class='card'>";
            echo "<h3>" . $fila["titulo"] . "</h3>";
            echo "<p>" . $fila["contenido"] . "</p>";
            echo "<small>Publicado el " . $fila["fecha"] . "</small>";
            echo "</div>";
          }
        ?>
      </div>
    </div>
  </div>

</body>
</html>
