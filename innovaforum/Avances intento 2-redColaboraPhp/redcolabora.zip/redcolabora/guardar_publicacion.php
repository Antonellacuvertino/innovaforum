<?php
session_start();
include("conexion.php");

$titulo = $_POST["titulo"];
$desc = $_POST["descripcion"];
$usuarioId = $_SESSION["usuario_id"];

$sql = "INSERT INTO publicaciones (titulo, descripcion, usuario_id) VALUES ('$titulo', '$desc', $usuarioId)";
if ($conexion->query($sql)) {
    echo "✅ Publicación guardada. <a href='publicaciones.php'>Ver publicaciones</a>";
} else {
    echo "❌ Error: " . $conexion->error;
}
?>
