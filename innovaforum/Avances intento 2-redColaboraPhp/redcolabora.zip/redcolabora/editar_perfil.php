<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$id = $_SESSION['usuario_id'];
$nombre = $_POST['nombre'];
$biografia = $_POST['biografia'];

// Foto
$foto = '';
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    $tmp = $_FILES['foto']['tmp_name'];
    $nombreArchivo = uniqid() . "_" . basename($_FILES['foto']['name']);
    $rutaDestino = "uploads/" . $nombreArchivo;
    move_uploaded_file($tmp, $rutaDestino);
    $foto = $nombreArchivo;
}

$sql = "UPDATE usuarios SET nombre = '$nombre', biografia = '$biografia'";
if ($foto !== '') {
    $sql .= ", foto = '$foto'";
}
$sql .= " WHERE id = $id";

$conexion->query($sql);
header("Location: perfil.php");
