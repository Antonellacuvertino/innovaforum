<?php
include("conexion.php");
$resultado = $conexion->query("SELECT p.titulo, p.descripcion, u.nombre, p.fecha 
FROM publicaciones p JOIN usuarios u ON p.usuario_id = u.id ORDER BY p.fecha DESC");

echo "<h2>Publicaciones</h2>";
while ($fila = $resultado->fetch_assoc()) {
    echo "<b>{$fila['titulo']}</b> por {$fila['nombre']}<br>";
    echo "<small>{$fila['fecha']}</small><br>";
    echo "<p>{$fila['descripcion']}</p><hr>";
}
?>
<p><a href='publicar.php'>Volver a publicar</a></p>
